---
layout: reference
---

## Glossary

IDE - Integrated development environment
[https://en.wikipedia.org/wiki/Integrated_development_environment](https://en.wikipedia.org/wiki/Integrated_development_environment)

{% include links.md %}
